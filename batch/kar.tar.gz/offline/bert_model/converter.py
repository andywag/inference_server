
def convert_model(model, mapping):
    